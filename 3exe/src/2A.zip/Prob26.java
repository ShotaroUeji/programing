
public class Prob26 {
	public static void main(String[] args) {
		MyPoint2 p = new MyPoint2();
		MyPoint2 q = new MyPoint2();
		
		p.setPoint(20,24);
		q.setPoint(4,19);
		
		p.printCoord();
		q.printCoord();
	}

}
