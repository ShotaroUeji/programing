
public class Prob24 {
	public static void main(String[] args) {
		Turtle t;
		t = new Turtle();
		t.move(110,200);
		t.penDown();
		t.setColor(java.awt.Color.blue);
		t.go(41);
		t.rotate(45);
		t.setColor(java.awt.Color.red);
		t.go(41);
		t.rotate(45);
		t.setColor(java.awt.Color.yellow);
		t.go(41);
		t.rotate(45);
		t.setColor(java.awt.Color.green);
		t.go(41);
		t.rotate(45);
		t.setColor(java.awt.Color.blue);
		t.go(41);
		t.rotate(45);
		t.setColor(java.awt.Color.red);
		t.go(41);
		t.rotate(45);
		t.setColor(java.awt.Color.yellow);
		t.go(41);
		t.rotate(45);
		t.setColor(java.awt.Color.green);
		t.go(41);
	}

}
